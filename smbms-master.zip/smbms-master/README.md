# 订单管理系统 smbms 狂神说Java

#### 介绍
 狂神说Java  Javaweb练习项目 JSP 订单管理系统



#### 安装教程

部署项目时可以参考以下文章

https://blog.csdn.net/zhuralll112/article/details/86238882

或者看着截图设置。
![打开项目设置](https://images.gitee.com/uploads/images/2021/0601/092634_c1bf248e_5396824.png "1.png")
![确保jdk版本](https://images.gitee.com/uploads/images/2021/0601/092653_e5354d63_5396824.png "2.png")
![添加Web模块](https://images.gitee.com/uploads/images/2021/0601/092702_ce3c6ba5_5396824.png "3.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092714_02e7e3c5_5396824.png "4.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092722_166d5352_5396824.png "5.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092729_ac8e1686_5396824.png "6.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092736_8df7f931_5396824.png "7.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/093440_def6b15c_5396824.png "12.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092742_d0e14c7a_5396824.png "8.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/093450_50b4c338_5396824.png "13.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092750_a66a122a_5396824.png "9.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092758_27885e7b_5396824.png "10.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0601/092806_2be4891a_5396824.png "11.png")