package cn.smbms.service.role;

import cn.smbms.pojo.Role;

import java.util.List;

public interface RoleService {
	
	public List<Role> getRoleList();
	
}
