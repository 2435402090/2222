package cn.smbms.tools;

/**
 * 自定义的Constants存放常量，方便前端jsp页面调用
 * */
public class Constants {
	public final static String USER_SESSION = "userSession";
	public final static String SYS_MESSAGE = "message";
	public final static int pageSize = 5;
}
